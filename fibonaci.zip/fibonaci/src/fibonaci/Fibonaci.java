package fibonaci;

public class Fibonaci {

    public void showFibonaci() {
        System.out.println("The 45 sequence Fibonaci: ");
        for (int i = 0; i < 45; i++) {
            System.out.print(fibonaci(i) + " ");
        }
    }

    public static int fibonaci(int n) {
        if (n < 0) {
            return -1;
        } else if (n == 0 || n == 1) {
            return n;
        } else {
            return fibonaci(n - 1) + fibonaci(n - 2);
        }
    }
}
