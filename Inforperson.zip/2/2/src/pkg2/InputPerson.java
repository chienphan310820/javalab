package pkg2;

import java.util.Scanner;

public class InputPerson extends Person {

    public void Name() {
        Scanner n = new Scanner(System.in);
        System.out.println("====Manegement Person Programer====");
        System.out.println("Input Information of Person");
        System.out.print("Please input name: ");
        String name = n.nextLine();
    }

    public void Address() {
        Scanner a = new Scanner(System.in);
        System.out.print("Please input address: ");
        String address = a.nextLine();
    }

    public void checkInputSalary() {
        Scanner in = new Scanner(System.in);
        String str = null;
        int n = 0;
        while (true) {
            System.out.print("Please input salary: ");
            try {
                str = in.nextLine();
                n = Integer.parseInt(str);

            } catch (Exception ex) {
                System.out.println("You must input digidt.");
                continue;
            }
            if (n < 0) {
                System.out.println("Salary is greater than zero");
                continue;
            }
            System.out.println("Input Information of Person");
            break;
        }
    }
    
    void displayPersonInfo() {
        System.out.println("Information of Person you have entered: ");
        System.out.println("Name: " + name);
        System.out.println("Address: " + this.address);
        System.out.println("Salary: " + this.salary);
    }
}
