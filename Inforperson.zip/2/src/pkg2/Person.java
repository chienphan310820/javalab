package pkg2;

import java.util.Comparator;

public class Person implements Comparator<Person> {

    String name;
    String address;
    double salary;

    public Person() {
    }

    public Person(String name, String address, double salary) {
        this.name = name;
        this.address = address;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    void displayPersonInfo() {
        System.out.println("=================================== ");
        System.out.println("Information of Person you have entered: ");
        System.out.println("Name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Salary: " + salary);
    }

    @Override
    public int compare(Person p1, Person p2) {
        if (p1.getName().equalsIgnoreCase(p2.getName())) {
            return p1.getName().compareTo(p2.getName());
        }
        return p1.getName().compareTo(p2.getName());
    }

}
