package fibonaci;

public class Main {

    public static void main(String[] args) {
        Fibonaci show = new Fibonaci();
        show.showFibonaci();
        show.fibonaci(45);
    }
}
