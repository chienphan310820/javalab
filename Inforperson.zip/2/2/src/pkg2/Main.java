package pkg2;

public class Main {

    public static void main(String[] args) {
        InputPerson input = new InputPerson();
        input.Name();
        input.Address();
        input.checkInputSalary();
        input.displayPersonInfo();
    }
}
