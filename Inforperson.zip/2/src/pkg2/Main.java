package pkg2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Main {

    public static void main(String[] args) {
        InputPerson listPersons = new InputPerson();
        listPersons.showTitle();
        listPersons.add();
        listPersons.display();
    }

}
