package pkg2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class InputPerson extends Person {

    public void showTitle() {
        System.out.println("====Manegement Person Programer====");
        System.out.println("Input Information of Person");
    }

    int k = 0;
    ArrayList<Person> listPersons = new ArrayList<>();

    public void add() {
        while (k < 3) {
            listPersons.add(new Person(Name(), Address(), InputSalary()));
            k++;
        }
        Collections.sort(listPersons, new InputPerson());
    }

    public String Name() {
        Scanner n = new Scanner(System.in);
        System.out.print("Please input name: ");
        return n.nextLine();
    }

    public String Address() {
        Scanner a = new Scanner(System.in);
        System.out.print("Please input address: ");
        return a.nextLine();
    }

    public int InputSalary() {
        Scanner in = new Scanner(System.in);
        String str = null;
        int n = 0;
        while (true) {
            System.out.print("Please input salary: ");
            try {
                str = in.nextLine();
                n = Integer.parseInt(str);

            } catch (Exception ex) {
                System.out.println("You must input digidt.");
                continue;
            }
            if (n < 0) {
                System.out.println("Salary is greater than zero");
                continue;
            }
            System.out.println("Input Information of Person");
            break;
        }
        return n;
    }

    public void display() {

        for (Person listPerson : listPersons) {
            listPerson.displayPersonInfo();

        }
    }
}
